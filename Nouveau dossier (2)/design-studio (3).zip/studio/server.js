require('dotenv').config();
const express=require('express'),Database=require('better-sqlite3'),bcrypt=require('bcryptjs'),jwt=require('jsonwebtoken'),cookieParser=require('cookie-parser');
const E=process.env,LIMIT=+E.DAILY_LIMIT||10;
if(!E.JWT_SECRET)throw new Error('ضع JWT_SECRET في ملف .env');
const db=new Database(E.DB_PATH||'data.db');
db.exec(`create table if not exists users(id integer primary key,email text unique,hash text);
create table if not exists usage(user_id integer,day text,n integer default 0,primary key(user_id,day));
create table if not exists designs(id integer primary key,user_id integer,mode text,prompt text,code text,created text default current_timestamp);`);
for(const c of ['banned integer default 0','lim integer','created text'])try{db.exec('alter table users add column '+c)}catch{}
db.exec('create table if not exists settings(k text primary key,v text)');
const cfg=k=>db.prepare('select v from settings where k=?').get(k)?.v;
const setCfg=(k,v)=>db.prepare('insert into settings(k,v) values(?,?) on conflict(k) do update set v=excluded.v').run(k,String(v));
const dayLimit=()=>+cfg('daily_limit')||LIMIT;
const ADMINS=(E.ADMIN_EMAILS||'').toLowerCase().split(',').map(x=>x.trim()).filter(Boolean);
db.exec('create table if not exists models(id integer primary key,label text,provider text,model text,key_enc text,base text,enabled integer default 1,sort integer default 0)');
const crypto=require('crypto'),EK=crypto.createHash('sha256').update('models:'+E.JWT_SECRET).digest();
const enc=t=>{const iv=crypto.randomBytes(12),c=crypto.createCipheriv('aes-256-gcm',EK,iv),b=Buffer.concat([c.update(t,'utf8'),c.final()]);return Buffer.concat([iv,c.getAuthTag(),b]).toString('base64')};
const dec=x=>{const b=Buffer.from(x,'base64'),d=crypto.createDecipheriv('aes-256-gcm',EK,b.subarray(0,12));d.setAuthTag(b.subarray(12,28));return Buffer.concat([d.update(b.subarray(28)),d.final()]).toString('utf8')};
const app=express();app.set('trust proxy',1);
app.set('trust proxy',1);
app.use((q,res,n)=>{res.set({'X-Content-Type-Options':'nosniff','X-Frame-Options':'DENY','Referrer-Policy':'no-referrer','Content-Security-Policy':"default-src 'self'; script-src 'self' 'unsafe-inline' https://accounts.google.com/gsi/client; style-src 'self' 'unsafe-inline' https://accounts.google.com/gsi/style; img-src 'self' data: https://*.googleusercontent.com; connect-src 'self' https://accounts.google.com/gsi/; frame-src https://accounts.google.com/gsi/ about:; base-uri 'none'; form-action 'self'"});n()});
const hits=new Map();
app.use(['/api/login','/api/register'],(req,res,n)=>{const now=Date.now(),h=(hits.get(req.ip)||[]).filter(t=>now-t<9e5);
 if(h.length>=10)return res.status(429).json({error:'rate',message:'محاولات كثيرة، انتظر 15 دقيقة.'});h.push(now);hits.set(req.ip,h);n()});
app.use(express.json({limit:'8mb'}),cookieParser(),express.static('public'));
// حد محاولات الدخول والتسجيل: 10 كل 15 دقيقة لكل عنوان
const tries=new Map();
const throttle=(req,res,next)=>{const k=req.ip,n=Date.now(),a=(tries.get(k)||[]).filter(t=>n-t<9e5);
 if(a.length>=10)return res.status(429).json({error:'slow',message:'محاولات كثيرة، انتظر 15 دقيقة.'});a.push(n);tries.set(k,a);next()};
setInterval(()=>tries.clear(),36e5).unref();
// تنظيف الكود الناتج من النموذج: لا سكربتات ولا معالجات أحداث ولا عناصر خطرة
const clean=t=>t.replace(/<(script|iframe|object|embed|link|meta|base|foreignObject)\b[\s\S]*?(<\/\1>|\/>)/gi,'').replace(/<\/?(script|iframe|object|embed|link|meta|base|foreignObject)\b[^>]*>/gi,'').replace(/\son\w+\s*=\s*("[^"]*"|'[^']*'|[^\s>]+)/gi,'').replace(/javascript:/gi,'');

// ---- الحسابات ----
const give=(res,u)=>res.cookie('t',jwt.sign({id:u.id,email:u.email},E.JWT_SECRET,{expiresIn:'30d'}),{httpOnly:true,sameSite:'lax',secure:E.NODE_ENV==='production',maxAge:30*864e5});
const auth=(req,res,next)=>{try{req.user=jwt.verify(req.cookies.t,E.JWT_SECRET);const u=db.prepare('select banned from users where id=?').get(req.user.id);if(!u||u.banned)throw 0;next()}catch{res.status(401).json({error:'login'})}};
app.post('/api/register',throttle,(req,res)=>{const{email,password}=req.body||{};
 if(cfg('signup_open')==='0')return res.status(403).json({error:'closed',message:'التسجيل مغلق حاليًا.'});
 if(!/^\S+@\S+\.\S+$/.test(email||'')||(password||'').length<8||password.length>72||email.length>254)return res.status(400).json({error:'bad',message:'بريد صحيح وكلمة مرور من 8 إلى 72 حرفًا'});
 try{const r=db.prepare('insert into users(email,hash) values(?,?)').run(email.toLowerCase(),bcrypt.hashSync(password,10));
  give(res,{id:r.lastInsertRowid,email});res.json({email})}catch{res.status(409).json({error:'exists',message:'هذا البريد مسجّل مسبقًا'})}});
app.post('/api/login',throttle,(req,res)=>{const{email,password}=req.body||{};
 const u=db.prepare('select * from users where email=?').get((email||'').toLowerCase());
 if(!u||!bcrypt.compareSync(password||'',u.hash))return res.status(401).json({error:'bad',message:'البريد أو كلمة المرور غير صحيحة'});
 give(res,u);res.json({email:u.email})});
app.post('/api/logout',(q,res)=>{res.clearCookie('t');res.json({})});
app.get('/api/me',auth,(req,res)=>res.json({email:req.user.email}));

// ---- النماذج ----
const MODELS={
 'claude-quick':{label:'Claude — سريع',key:E.ANTHROPIC_API_KEY,id:E.CLAUDE_QUICK||'claude-haiku-5-5',p:'claude'},
 'claude-balanced':{label:'Claude — متوازن',key:E.ANTHROPIC_API_KEY,id:E.CLAUDE_BALANCED||'claude-sonnet-5-5',p:'claude'},
 'claude-advanced':{label:'Claude — متقدم',key:E.ANTHROPIC_API_KEY,id:E.CLAUDE_ADVANCED||'claude-opus-5-5',p:'claude'},
 'gpt':{label:'GPT',key:E.OPENAI_API_KEY,id:E.OPENAI_MODEL,p:'openai'},
 'gemini':{label:'Gemini',key:E.GEMINI_API_KEY,id:E.GEMINI_MODEL,p:'gemini'}};
const on=(k,R)=>R[k]&&R[k].key&&R[k].id;
function reg(){const o={...MODELS};for(const r of db.prepare('select * from models where enabled=1 order by sort,id').all()){try{o['m'+r.id]={label:r.label,key:dec(r.key_enc),id:r.model,p:r.provider,base:r.base}}catch{}}return o}
async function post(url,headers,body){const r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json',...headers},body:JSON.stringify(body)});
 const j=await r.json();if(!r.ok)throw new Error(j.error?.message||JSON.stringify(j).slice(0,200));return j}
const ASK={
 claude:async(m,sys,msgs,im)=>(await post('https://api.anthropic.com/v1/messages',{'x-api-key':m.key,'anthropic-version':'2023-06-01'},{model:m.id,max_tokens:8000,system:sys,messages:msgs.map((x,n)=>n===msgs.length-1&&im.length?{role:x.role,content:[...im.map(i=>({type:'image',source:{type:'base64',media_type:i.type,data:i.data}})),{type:'text',text:x.content}]}:x)})).content.map(c=>c.text||'').join(''),
 openai:async(m,sys,msgs,im)=>(await post((m.base||'https://api.openai.com/v1')+'/chat/completions',{Authorization:'Bearer '+m.key},{model:m.id,messages:[{role:'system',content:sys},...msgs.map((x,n)=>n===msgs.length-1&&im.length?{role:x.role,content:[{type:'text',text:x.content},...im.map(i=>({type:'image_url',image_url:{url:`data:${i.type};base64,${i.data}`}}))]}:x)]})).choices[0].message.content,
 gemini:async(m,sys,msgs,im)=>(await post(`https://generativelanguage.googleapis.com/v1beta/models/${m.id}:generateContent`,{'x-goog-api-key':m.key},{systemInstruction:{parts:[{text:sys}]},contents:msgs.map((x,n)=>({role:x.role==='assistant'?'model':'user',parts:[{text:x.content},...(n===msgs.length-1?im.map(i=>({inlineData:{mimeType:i.type,data:i.data}})):[])]}))})).candidates[0].content.parts[0].text};
app.get('/api/models',(q,res)=>{const R=reg();res.json(Object.keys(R).filter(k=>on(k,R)).map(k=>({id:k,label:R[k].label})))});

// التعليمات تبقى في الخادم حتى لا يغيّرها المستخدم
const RULES='أجب فقط عن الشعارات والتصميم وصفحات الويب والألوان والخطوط؛ وإن كان الطلب خارج ذلك فاعتذر بجملة قصيرة واقترح فكرة تصميم. اكتب ردًا عربيًا من جملتين كحد أقصى ثم الكود في كتلة واحدة. بلا سكربتات ولا صور خارجية ولا خطوط خارجية. عند طلب تعديل عدّل آخر نسخة. الأسلوب الافتراضي: أسود ورمادي أنيق ما لم يُطلب غيره.';
const SYS={
 chat:'أنت مساعد ذكاء اصطناعي عام وودود يجيب عن أي سؤال بالعربية بوضوح ودقة وإيجاز، وتتميز بخبرة عميقة في التصميم والهوية البصرية (الألوان والخطوط والشعارات والعلامات التجارية). عند أي سؤال في التصميم أو الهوية البصرية أعطِ إجابة أعمق وأمثلة عملية. وإذا أراد المستخدم تصميمًا أو شعارًا أو هوية كاملة فاقترح عليه التبديل إلى التبويب المناسب للحصول على معاينة فورية.',
 brand:'أنت مصمم هويات بصرية محترف. أعطِ لوحة هوية بصرية كاملة كصفحة HTML واحدة (من <!DOCTYPE html> إلى </html>) فيها: اسم العلامة، وشعار SVG مضمّن، ولوحة ألوان برموز HEX، وخطوط النظام المقترحة، وقواعد استخدام الشعار، وأمثلة تطبيق (بطاقة، ترويسة) بـ CSS فقط.',
 logo:'أنت مصمم شعارات محترف. أعطِ شعارًا واحدًا بصيغة SVG كاملة (<svg viewBox="0 0 400 400" xmlns="http://www.w3.org/2000/svg">…</svg>) بتصميم نظيف وبسيط.',
 design:'أنت مصمم جرافيك. أعطِ تصميمًا واحدًا بصيغة SVG كاملة مع viewBox مناسب للنوع المطلوب وتكوين بصري واضح.',
 web:'أنت مطور واجهات. أعطِ صفحة ويب واحدة كاملة بصيغة HTML (من <!DOCTYPE html> إلى </html>) فيها CSS داخلي فقط ومتجاوبة، وتدعم RTL عند الحاجة.'};
const today=()=>new Date().toISOString().slice(0,10);
app.post('/api/generate',auth,async(req,res)=>{
 const{mode,model,messages}=req.body||{},R=reg(),m=R[model];
 const im=(Array.isArray(req.body?.images)?req.body.images:[]).slice(0,3).filter(i=>i&&['image/jpeg','image/png','image/webp'].includes(i.type)&&typeof i.data==='string'&&i.data.length<3e6);
 if(!SYS[mode]||!m||!on(model,R)||!Array.isArray(messages)||!messages.length)return res.status(400).json({error:'bad',message:'طلب غير صالح'});
 const msgs=messages.slice(-10).map(x=>({role:x.role==='assistant'?'assistant':'user',content:String(x.content||'').slice(0,30000)}));
 while(msgs.length&&msgs[0].role==='assistant')msgs.shift();
 if(!msgs.length||msgs[msgs.length-1].role!=='user')return res.status(400).json({error:'bad',message:'طلب غير صالح'});
 const used=db.prepare('select n from usage where user_id=? and day=?').get(req.user.id,today())?.n||0;
 const LM=db.prepare('select lim from users where id=?').get(req.user.id)?.lim||dayLimit();
 if(used>=LM)return res.status(429).json({error:'limit',message:`وصلت إلى الحد اليومي (${LM} طلبات). عُد غدًا.`});
db.prepare('insert into usage(user_id,day,n) values(?,?,1) on conflict(user_id,day) do update set n=n+1').run(req.user.id,today());
 try{const text=clean(await ASK[m.p](m,SYS[mode]+(mode==='chat'?'':' '+RULES),msgs,im));
  const code=(text.match(/<svg[\s\S]*?<\/svg>/i)||text.match(/<!DOCTYPE html[\s\S]*?<\/html>/i)||[])[0];
  if(code)db.prepare('insert into designs(user_id,mode,prompt,code) values(?,?,?,?)').run(req.user.id,mode,msgs[msgs.length-1].content.slice(0,300),code);
  res.json({text,remaining:LM-used-1})}
 catch(e){db.prepare('update usage set n=n-1 where user_id=? and day=?').run(req.user.id,today());console.error(e.message);res.status(502).json({error:'model',message:'تعذّر الاتصال بالنموذج، حاول لاحقًا.'})}});
app.get('/api/config',(q,res)=>res.json({googleClientId:E.GOOGLE_CLIENT_ID||'',announcement:cfg('announcement')||'',signupOpen:cfg('signup_open')!=='0'}));
app.post('/api/google',async(req,res)=>{try{
 const r=await fetch('https://oauth2.googleapis.com/tokeninfo?id_token='+encodeURIComponent(String(req.body?.credential||''))),j=await r.json();
 if(!E.GOOGLE_CLIENT_ID||!r.ok||j.aud!==E.GOOGLE_CLIENT_ID||j.email_verified!=='true')return res.status(401).json({error:'google',message:'تعذّر التحقق من حساب Google'});
 const email=String(j.email).toLowerCase();let u=db.prepare('select * from users where email=?').get(email);
 if(!u&&cfg('signup_open')==='0')return res.status(403).json({error:'closed',message:'التسجيل مغلق حاليًا.'});
 if(!u){const x=db.prepare('insert into users(email,hash) values(?,?)').run(email,bcrypt.hashSync(require('crypto').randomBytes(24).toString('hex'),10));u={id:x.lastInsertRowid,email}}
 give(res,u);res.json({email})}catch{res.status(502).json({error:'google',message:'تعذّر الاتصال بـ Google'})}});
app.get('/api/designs',auth,(req,res)=>res.json(db.prepare('select id,mode,prompt,created from designs where user_id=? order by id desc limit 30').all(req.user.id)));
app.get('/api/designs/:id',auth,(req,res)=>{const d=db.prepare('select * from designs where id=? and user_id=?').get(req.params.id,req.user.id);d?res.json(d):res.status(404).json({})});
app.delete('/api/designs/:id',auth,(req,res)=>{db.prepare('delete from designs where id=? and user_id=?').run(req.params.id,req.user.id);res.json({})});
// ---- لوحة التحكم عن بعد (صفحة /admin.html منفصلة عن التطبيق) ----
const adm=(req,res,next)=>auth(req,res,()=>ADMINS.includes(String(req.user.email).toLowerCase())?next():res.status(403).json({error:'admin',message:'ليس لديك صلاحية'}));
app.get('/api/admin/stats',adm,(q,res)=>{const g=(sql,...a)=>db.prepare(sql).get(...a);
 res.json({users:g('select count(*) n from users').n,designs:g('select count(*) n from designs').n,today:g('select coalesce(sum(n),0) n from usage where day=?',today()).n,total:g('select coalesce(sum(n),0) n from usage').n,
  byMode:db.prepare('select mode,count(*) n from designs group by mode').all(),limit:dayLimit(),signupOpen:cfg('signup_open')!=='0',announcement:cfg('announcement')||''})});
app.get('/api/admin/users',adm,(q,res)=>res.json(db.prepare(`select u.id,u.email,u.banned,u.lim,coalesce((select n from usage where user_id=u.id and day=?),0) today,(select count(*) from designs where user_id=u.id) designs from users u order by u.id desc limit 200`).all(today())));
app.post('/api/admin/users/:id',adm,(req,res)=>{const{banned,lim}=req.body||{};
 if(banned!==undefined)db.prepare('update users set banned=? where id=?').run(banned?1:0,req.params.id);
 if(lim!==undefined)db.prepare('update users set lim=? where id=?').run(+lim>0?Math.min(+lim,1000):null,req.params.id);res.json({})});
app.post('/api/admin/settings',adm,(req,res)=>{const{announcement,daily_limit,signup_open}=req.body||{};
 if(announcement!==undefined)setCfg('announcement',String(announcement).slice(0,300));
 if(daily_limit!==undefined&&+daily_limit>0)setCfg('daily_limit',Math.min(+daily_limit,1000));
 if(signup_open!==undefined)setCfg('signup_open',signup_open?'1':'0');res.json({})});
app.get('/api/admin/designs',adm,(q,res)=>res.json(db.prepare('select d.id,d.mode,d.prompt,d.created,u.email from designs d join users u on u.id=d.user_id order by d.id desc limit 30').all()));
// ---- إدارة النماذج من لوحة التحكم (المفاتيح مشفّرة في قاعدة البيانات ولا تُعاد للمتصفح) ----
const hint=r=>{try{return '••••'+dec(r.key_enc).slice(-4)}catch{return '؟'}};
app.get('/api/admin/models',adm,(q,res)=>res.json(db.prepare('select * from models order by sort,id').all().map(r=>({id:r.id,label:r.label,provider:r.provider,model:r.model,base:r.base||'',enabled:!!r.enabled,hint:hint(r)}))));
app.post('/api/admin/models',adm,(req,res)=>{const{label,provider,model,key,base}=req.body||{};
 if(!label||!model||!key||!['claude','openai','gemini'].includes(provider))return res.status(400).json({message:'أكمل الحقول'});
 if(base&&!/^https:\/\/\S+$/.test(base))return res.status(400).json({message:'الرابط يجب أن يبدأ بـ https://'});
 const r=db.prepare('insert into models(label,provider,model,key_enc,base) values(?,?,?,?,?)').run(String(label).slice(0,60),provider,String(model).slice(0,100),enc(String(key).trim()),base?String(base).replace(/\/$/,''):null);res.json({id:r.lastInsertRowid})});
app.post('/api/admin/models/:id',adm,(req,res)=>{const{enabled,key,label}=req.body||{};
 if(enabled!==undefined)db.prepare('update models set enabled=? where id=?').run(enabled?1:0,req.params.id);
 if(key)db.prepare('update models set key_enc=? where id=?').run(enc(String(key).trim()),req.params.id);
 if(label)db.prepare('update models set label=? where id=?').run(String(label).slice(0,60),req.params.id);res.json({})});
app.delete('/api/admin/models/:id',adm,(req,res)=>{db.prepare('delete from models where id=?').run(req.params.id);res.json({})});
app.post('/api/admin/models/:id/test',adm,async(req,res)=>{const m=reg()['m'+req.params.id];
 if(!m)return res.json({ok:false,message:'النموذج موقوف أو تعذّر فك المفتاح'});
 try{const t=await ASK[m.p](m,'أجب بكلمة واحدة فقط.',[{role:'user',content:'قل: تم'}],[]);res.json({ok:true,message:String(t).slice(0,80)})}catch(e){res.json({ok:false,message:String(e.message).slice(0,200)})}});
app.listen(E.PORT||3000,()=>console.log('http://localhost:'+(E.PORT||3000)));
